package com.bateman.hangmanv6;

public interface WordGame {
  public abstract String currentIncompleteWord();
}
