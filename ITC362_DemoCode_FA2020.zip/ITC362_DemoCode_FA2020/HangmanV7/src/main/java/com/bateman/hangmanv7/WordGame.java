package com.bateman.hangmanv7;

public interface WordGame {
  public abstract String currentIncompleteWord();
}
