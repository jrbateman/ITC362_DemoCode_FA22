package bateman.hellogoodbye;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView greetingTextView;
    private boolean isHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button exclaimBtn = findViewById(R.id.button);
        greetingTextView =  findViewById(R.id.textView);
        final ImageView helloImage = findViewById(R.id.IV_Hello);
            helloImage.setImageAlpha(120);
        final ImageView goodbyeImage = findViewById(R.id.IV_Goodbye);
            goodbyeImage.setImageAlpha(120);

        initializeGreeting();

        exclaimBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isHello) {
                    isHello = false;
                    greetingTextView.setText(R.string.goodbye);
                    helloImage.setVisibility(View.INVISIBLE);
                    goodbyeImage.setVisibility(View.VISIBLE);
                } else {
                    isHello = true;
                    greetingTextView.setText(R.string.hello);
                    helloImage.setVisibility(View.VISIBLE);
                    goodbyeImage.setVisibility(View.INVISIBLE);
                }

            }
        });

    }

    private void initializeGreeting() {
    }
}
