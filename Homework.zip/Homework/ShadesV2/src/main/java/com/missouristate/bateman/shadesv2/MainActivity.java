package com.missouristate.bateman.shadesv2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.graphics.Point;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button[][] buttons;
    private int rowCount = 3;
    private int colCount = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ConstraintLayout layout = (ConstraintLayout) findViewById(R.id.cl_1);
        ConstraintSet set = new ConstraintSet();
        set.clone(layout);

        //Button 1:
        Button button = new Button(this);
        button.setText("Hello");
        //button.setId(0b1);           // <-- Important
        layout.addView(button);
        set.connect(button.getId(), ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0);
        set.connect(button.getId(),ConstraintSet.RIGHT,ConstraintSet.PARENT_ID,ConstraintSet.RIGHT,0);
        set.connect(button.getId(),ConstraintSet.LEFT,ConstraintSet.PARENT_ID,ConstraintSet.LEFT,0);
        set.constrainHeight(button.getId(), 200);
        set.applyTo(layout);


        //Button 2:
        Button newButton = new Button(this);
        newButton.setText("Yeeey");
        layout.addView(newButton);
        set.connect(newButton.getId(), ConstraintSet.BOTTOM, button.getId(), ConstraintSet.TOP, 0);
        set.connect(newButton.getId(),ConstraintSet.RIGHT,ConstraintSet.PARENT_ID,ConstraintSet.RIGHT,0);
        set.connect(newButton.getId(),ConstraintSet.LEFT,ConstraintSet.PARENT_ID,ConstraintSet.LEFT,0);
        set.constrainHeight(newButton.getId(), 200);
        set.applyTo(layout);

    }


    }

